/* API Version - 2.2 */

function AutoDetectionMidiPortNames() {}

/**
 * @return {String[]}
 */
AutoDetectionMidiPortNames.prototype.getInputNames = function() {};

/**
 * @return {String[]}
 */
AutoDetectionMidiPortNames.prototype.getOutputNames = function() {};
