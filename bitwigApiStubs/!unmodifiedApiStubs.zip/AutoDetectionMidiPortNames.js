/* API Version - 2.1.3 */

function AutoDetectionMidiPortNames() {}

/**
 * @return {String[]}
 */
AutoDetectionMidiPortNames.prototype.getInputNames = function() {};

/**
 * @return {String[]}
 */
AutoDetectionMidiPortNames.prototype.getOutputNames = function() {};
