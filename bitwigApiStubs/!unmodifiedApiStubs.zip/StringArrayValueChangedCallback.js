/* API Version - 2.1.3 */

function StringArrayValueChangedCallback() {}

StringArrayValueChangedCallback.prototype = new ObjectValueChangedCallback();
StringArrayValueChangedCallback.prototype.constructor = StringArrayValueChangedCallback;
