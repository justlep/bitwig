/* API Version - 2.2 */

function StringArrayValueChangedCallback() {}

StringArrayValueChangedCallback.prototype = new ObjectValueChangedCallback();
StringArrayValueChangedCallback.prototype.constructor = StringArrayValueChangedCallback;
