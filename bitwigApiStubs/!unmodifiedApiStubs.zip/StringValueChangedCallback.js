/* API Version - 2.1.3 */

function StringValueChangedCallback() {}

StringValueChangedCallback.prototype = new ObjectValueChangedCallback();
StringValueChangedCallback.prototype.constructor = StringValueChangedCallback;
