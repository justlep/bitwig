/* API Version - 2.2 */

function ValueChangedCallback() {}

ValueChangedCallback.prototype = new Callback();
ValueChangedCallback.prototype.constructor = ValueChangedCallback;
