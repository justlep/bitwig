/* API Version - 2.1.3 */

function EnumValueChangedCallback() {}

EnumValueChangedCallback.prototype = new ObjectValueChangedCallback();
EnumValueChangedCallback.prototype.constructor = EnumValueChangedCallback;
