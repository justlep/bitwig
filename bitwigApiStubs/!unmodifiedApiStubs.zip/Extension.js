/* API Version - 2.2 */

function Extension() {}

/**
 * @return {HostType}
 */
Extension.prototype.getHost = function() {};

/**
 * @return {DefinitionType}
 */
Extension.prototype.getExtensionDefinition = function() {};
