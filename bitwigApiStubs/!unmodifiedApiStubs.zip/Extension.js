/* API Version - 2.1.3 */

function Extension() {}

/**
 * @return {HostType}
 */
Extension.prototype.getHost = function() {};

/**
 * @return {DefinitionType}
 */
Extension.prototype.getExtensionDefinition = function() {};
