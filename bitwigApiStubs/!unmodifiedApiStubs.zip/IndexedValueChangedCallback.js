/* API Version - 2.2 */

function IndexedValueChangedCallback() {}

IndexedValueChangedCallback.prototype = new Callback();
IndexedValueChangedCallback.prototype.constructor = IndexedValueChangedCallback;
