/* API Version - 2.1.3 */

function IndexedValueChangedCallback() {}

IndexedValueChangedCallback.prototype = new Callback();
IndexedValueChangedCallback.prototype.constructor = IndexedValueChangedCallback;
