/* API Version - 2.1.3 */

com.bitwig.extension.api.PlatformType = {
	WINDOWS: 0,
	LINUX: 1,
	MAC: 2,
};