/* API Version - 2.2 */

/**
 * Instances of this interface represent entries in a browser column.
 *
 * @since API version 1
 */
function CursorBrowserResultItem() {}

CursorBrowserResultItem.prototype = new BrowserResultsItem();
CursorBrowserResultItem.prototype.constructor = CursorBrowserResultItem;
