/* API Version - 2.2 */

function SendBank() {}

SendBank.prototype = new Bank();
SendBank.prototype.constructor = SendBank;
