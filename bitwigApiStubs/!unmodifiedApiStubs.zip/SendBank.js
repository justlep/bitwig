/* API Version - 2.1.3 */

function SendBank() {}

SendBank.prototype = new Bank();
SendBank.prototype.constructor = SendBank;
