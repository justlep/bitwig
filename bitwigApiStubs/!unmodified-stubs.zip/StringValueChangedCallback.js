/* API Version - 2.2.3 */

function StringValueChangedCallback() {}

StringValueChangedCallback.prototype = new ObjectValueChangedCallback();
StringValueChangedCallback.prototype.constructor = StringValueChangedCallback;
