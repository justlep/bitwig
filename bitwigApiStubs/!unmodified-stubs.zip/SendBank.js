/* API Version - 2.3.1 */

function SendBank() {}

SendBank.prototype = new Bank();
SendBank.prototype.constructor = SendBank;
