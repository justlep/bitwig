/* API Version - 2.2.3 */

function SendBank() {}

SendBank.prototype = new Bank();
SendBank.prototype.constructor = SendBank;
