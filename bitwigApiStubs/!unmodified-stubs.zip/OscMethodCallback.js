/* API Version - 2.3.1 */

function OscMethodCallback() {}

/**
 * @param {com.bitwig.extension.api.opensoundcontrol.OscConnection} source
 * @param {com.bitwig.extension.api.opensoundcontrol.OscMessage} message
 */
OscMethodCallback.prototype.handle = function(source, message) {};
