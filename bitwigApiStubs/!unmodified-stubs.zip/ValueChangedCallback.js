/* API Version - 2.3.1 */

function ValueChangedCallback() {}

ValueChangedCallback.prototype = new Callback();
ValueChangedCallback.prototype.constructor = ValueChangedCallback;
