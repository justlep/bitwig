/* API Version - 2.3.1 */

function EnumValueChangedCallback() {}

EnumValueChangedCallback.prototype = new ObjectValueChangedCallback();
EnumValueChangedCallback.prototype.constructor = EnumValueChangedCallback;
