/* API Version - 2.3.1 */

function OscNode() {}

/**
 * @return {string}
 */
OscNode.prototype.prefix = function() {};
