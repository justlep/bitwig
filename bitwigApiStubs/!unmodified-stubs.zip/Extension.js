/* API Version - 2.3.1 */

function Extension() {}

/**
 * @return {HostType}
 */
Extension.prototype.getHost = function() {};

/**
 * @return {DefinitionType}
 */
Extension.prototype.getExtensionDefinition = function() {};
