/* API Version - 2.2.3 */

function AutoDetectionMidiPortNames() {}

/**
 * @return {String[]}
 */
AutoDetectionMidiPortNames.prototype.getInputNames = function() {};

/**
 * @return {String[]}
 */
AutoDetectionMidiPortNames.prototype.getOutputNames = function() {};
