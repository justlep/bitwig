/* API Version - 2.3.1 */

function IndexedValueChangedCallback() {}

IndexedValueChangedCallback.prototype = new Callback();
IndexedValueChangedCallback.prototype.constructor = IndexedValueChangedCallback;
