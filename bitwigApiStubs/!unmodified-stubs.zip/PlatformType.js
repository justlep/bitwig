/* API Version - 2.3.1 */

com.bitwig.extension.api.PlatformType = {
	WINDOWS: 0,
	LINUX: 1,
	MAC: 2,
};