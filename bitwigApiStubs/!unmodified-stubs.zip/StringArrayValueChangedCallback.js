/* API Version - 2.2.3 */

function StringArrayValueChangedCallback() {}

StringArrayValueChangedCallback.prototype = new ObjectValueChangedCallback();
StringArrayValueChangedCallback.prototype.constructor = StringArrayValueChangedCallback;
