/* API Version - 2.3.1 */

function StringArrayValueChangedCallback() {}

StringArrayValueChangedCallback.prototype = new ObjectValueChangedCallback();
StringArrayValueChangedCallback.prototype.constructor = StringArrayValueChangedCallback;
