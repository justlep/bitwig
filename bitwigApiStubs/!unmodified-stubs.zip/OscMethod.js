/* API Version - 2.3.1 */

function OscMethod() {}

/**
 * @return {string}
 */
OscMethod.prototype.address = function() {};

/**
 * @return {string}
 */
OscMethod.prototype.typeTagPattern = function() {};

/**
 * @return {string}
 */
OscMethod.prototype.desc = function() {};

/**
 * @return {String[]}
 */
OscMethod.prototype.obsoleteAddresses = function() {};
