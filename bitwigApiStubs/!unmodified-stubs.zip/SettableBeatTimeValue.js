/* API Version - 2.2.3 */

function SettableBeatTimeValue() {}

SettableBeatTimeValue.prototype = new BeatTimeValue();
SettableBeatTimeValue.prototype.constructor = SettableBeatTimeValue;
