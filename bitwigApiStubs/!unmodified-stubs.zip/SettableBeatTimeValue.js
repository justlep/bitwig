/* API Version - 2.3.1 */

function SettableBeatTimeValue() {}

SettableBeatTimeValue.prototype = new BeatTimeValue();
SettableBeatTimeValue.prototype.constructor = SettableBeatTimeValue;
