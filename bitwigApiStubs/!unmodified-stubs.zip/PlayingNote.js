/* API Version - 2.3.1 */

/**
 * @since API version 2
 */
function PlayingNote() {}

/**
 * @return {int}
 * @since API version 2
 */
PlayingNote.prototype.pitch = function() {};

/**
 * @return {int}
 * @since API version 2
 */
PlayingNote.prototype.velocity = function() {};
