/* API Version - 2.3.1 */

function OscPacketSizeExceededException() {}
