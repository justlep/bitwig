
To make a syx to switch to a different preset:

1) make a copy of `switch-preset-29-via-sysex.txt`

2) e.g. for Preset XY 
     -> Search for `32 39`
     -> Replace with `3X 3Y`

3) Convert the txt file to sysex, e.g. using 
   http://www.bwalk.com.au/MidiUtil/FileConvert.html